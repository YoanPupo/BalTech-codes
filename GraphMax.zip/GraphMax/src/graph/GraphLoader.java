/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author YULIER
 */
public class GraphLoader {

    public static void loadGraphFile(Graph target, File source) {
        Map<Integer, String> keys = new HashMap<>();
        try {
            try (Scanner reader = new Scanner(source)) {

                String headerLine = null;
                /*leer vertices*/
                while (!(reader.nextLine().trim()).contains("nodes"));
                while (!(headerLine = reader.nextLine()).trim().contains("}")) {
                    if (headerLine.contains("//")) {
                        headerLine = headerLine.substring(0, headerLine.indexOf("//"));
                    }
                    StringTokenizer cutter = new StringTokenizer(headerLine, ":");
                    if (cutter.countTokens() < 2) {
                        continue;
                    }
                    //leer identificador 
                    int index = Integer.parseInt(cutter.nextToken().trim());
                    //leer valor
                    String value = cutter.nextToken();
                    int start = value.indexOf("\"") + 1;
                    int end = value.lastIndexOf("\"");
                    value = value.substring(start, end);
                    //guardar valor e identif. en tabla
                    keys.put(index, value);
                    double x, y;
                    if (cutter.hasMoreElements()) {//archivo incluye coordenadas,leer
                        x = Double.parseDouble(cutter.nextToken().trim());
                        y = Double.parseDouble(cutter.nextToken().trim());
                    } else {//archivo no incluye coordenadas,asignar aleatorio
                        x = Math.random() * 1000;
                        y = Math.random() * 1000;
                    }
                    //agregar a grafo
                    target.add(value);
                    GraphNode node = target.get(value);
                    node.moveTo(x, y);
                }
                /*leer aristas*/
                while (!(reader.nextLine().trim()).contains("links"));
                while (!(headerLine = reader.nextLine().trim()).contains("}")) {
                    if (headerLine.contains("//")) {
                        headerLine = headerLine.substring(0, headerLine.indexOf("//"));
                    }
                    StringTokenizer cutter = new StringTokenizer(headerLine, ":");
                    if (cutter.countTokens() < 3) {
                        continue;
                    }
                    //lee vertice inicio
                    int from = Integer.parseInt(cutter.nextToken().trim());
                    //lee vertice fin
                    int to = Integer.parseInt(cutter.nextToken().trim());
                    //lee peso
                    int weight = Integer.parseInt(cutter.nextToken().trim());
                    //agrega al grafo
                    target.addLink(keys.get(from), keys.get(to), weight);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "ERROR\n\narchivo de grafo invalido\n" + ex.getLocalizedMessage());
            target.clear();
            return;
        }
    }

    public static void saveGraphFile(Graph target, File source) {
        Map< String, Integer> keys = new HashMap<>();
        try {
            PrintWriter writer = new PrintWriter(source);
            //guarda vertices
            writer.println("nodes {");
            int cont = 0;
            for (GraphNode node : target.getNodes()) {
                writer.println("    " + cont + " : \"" + node.value + "\" : " + node.getX() + " : " + node.getY());
                keys.put(node.getValue(), cont);
                cont++;
            }
            //guarda aristas
            writer.println("}");
            writer.println("links {");
            for (GraphNode node : target.getNodes()) {
                for (GraphLink link : node.getLinks()) {
                    writer.println("    " + keys.get(node.getValue()) + " : " + keys.get(link.getTo().getValue()) + " : " + link.getWeight());
                }
            }
            writer.println("}");
            writer.flush();
            writer.close();

        } catch (Exception ex) {
            Logger.getLogger(GraphLoader.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
