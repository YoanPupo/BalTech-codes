/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import ObjectSerializator.DataReader;
import ObjectSerializator.DataWriter;
import ObjectSerializator.ReadException;
import ObjectSerializator.Saveable;
import ObjectSerializator.WriteException;

/**
 *
 * @author YULIER
 */
public class GraphLink implements Comparable<GraphLink>{
    GraphNode To;
    int weight;

    public GraphLink() {
    }
    
    public GraphLink(GraphNode To, int weight) {
        this.To = To;
        this.weight = weight;
    }

    public GraphNode getTo() {
        return To;
    }

    public void setTo(GraphNode To) {
        this.To = To;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
    
   
    @Override
    public String toString() {
        return  To.getValue() + "  peso: "+ weight ;
    }

    @Override
    public int compareTo(GraphLink o) {
      return (weight-o.weight);
    }

   
    
    

    
}
