/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import ObjectSerializator.DataReader;
import ObjectSerializator.DataWriter;
import ObjectSerializator.ReadException;
import ObjectSerializator.Saveable;
import ObjectSerializator.WriteException;
import java.awt.Graphics;
import graphics.*;
import java.awt.Color;
import java.util.List;

/**
 *
 * @author YULIER
 */
public class GraphNode extends GraphicObject {

    String value;
    List<GraphLink> links;
    boolean marked = false;
    GraphLink LinkMarked;

    public GraphNode() {
        super(0,0,25,25);
    }
    
    public GraphNode(String value) {
        super(0, 0, 25, 25);
        this.value = value;
        links = new DynamicList<>();

    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public List<GraphLink> getLinks() {
        return links;
    }

    public void addLink(GraphNode to, int weight) {
        for (GraphLink link : links) {
            if (link.getTo() == to) {
                links.remove(link);
            }
        }
        links.add(new GraphLink(to, weight));
    }

    public void mark() {
        marked = true;
    }

    public void markLink(GraphLink marked) {
        LinkMarked = marked;
    }

    public void removeLink(GraphNode to) {
        for (int i = 0; i < links.size(); i++) {
            GraphLink get = links.get(i);
            if (get.getTo() == to) {
                links.remove(get);
                break;
            }

        }
    }

    public void print(Graphics gc) {
        gc.setColor(Color.GRAY);
        if (marked) {
            gc.setColor(Color.DARK_GRAY);
        }
        gc.fillOval((int) getX(), (int) getY(), (int) getxSize(), (int) getySize());
        gc.setColor(Color.BLACK);

        gc.drawOval((int) getX(), (int) getY(), (int) getxSize(), (int) getySize());

        for (GraphLink link : links) {
            if (LinkMarked == link) {
                gc.setColor(Color.RED);
            } else {
                gc.setColor(Color.BLUE);
            }
            point from = getCenterPosition();
            point to = link.getTo().getCenterPosition();
            point center = new point(from, from.getDirection(to), from.distanceTo(to) / 2);

            Arrow arrow = new Arrow(from, to);
            arrow.draw(gc);
            gc.setColor(Color.BLACK);

            gc.drawString(link.weight + "", (int) (center.getX() - 10), (int) (center.getY() - 10));
        }
        gc.setColor(Color.BLACK);
        gc.drawString(value, (int) (getX() - 10), (int) (getY() - 10));
        marked = false;
        LinkMarked = null;
    }

   

}
