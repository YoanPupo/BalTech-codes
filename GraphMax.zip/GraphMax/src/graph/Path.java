/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

/**
 *
 * @author YULIER
 */
public class Path implements Comparable<Path>{
    GraphNode target;
    double coast;

    public Path(GraphNode target, double coast) {
        this.target = target;
        this.coast = coast;
    }

    public GraphNode getTarget() {
        return target;
    }

    public void setTarget(GraphNode target) {
        this.target = target;
    }

    public double getCoast() {
        return coast;
    }

    public void setCoast(double coast) {
        this.coast = coast;
    }

    @Override
    public int compareTo(Path o) {
       return (int) (coast-o.coast);
    }
    
}
