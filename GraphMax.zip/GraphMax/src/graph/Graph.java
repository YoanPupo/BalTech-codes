/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import ObjectSerializator.DataReader;
import ObjectSerializator.DataWriter;
import ObjectSerializator.ReadException;
import ObjectSerializator.Saveable;
import ObjectSerializator.WriteException;
import graphics.DynamicList;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

/**
 *
 * @author YULIER
 */
public class Graph {

    List<GraphNode> nodes;
    Map<String, GraphNode> values = new HashMap<>();
    boolean isDirectionable;
    List<GraphChangueListener> ChangueListeners;

    public Graph() {
        nodes = new DynamicList<>();
        ChangueListeners = new DynamicList<>();
    }

    public Graph(boolean direct) {
        isDirectionable = direct;
    }

    public void clear() {
        nodes.clear();
        values.clear();
    }

    public boolean add(String value) throws RuntimeException {
        if (values.containsKey(value)) {
            return false;
        }
        GraphNode toAdd = new GraphNode(value);
        values.put(value, toAdd);
        nodes.add(toAdd);
        fireNodeAddedEvent(toAdd);
        return true;
    }

    public boolean remove(String value) {
        if (!values.containsKey(value)) {
            return false;
        }
        GraphNode toDel = values.get(value);
        fireNodeRemovedEvent(toDel);
        //elimina enlaces hacia el
        for (GraphNode node : nodes) {
            for (GraphLink link : node.getLinks()) {
                if (link.getTo() == toDel) {
                    node.removeLink(toDel);
                }
            }
        }
        //elimina enlaces desde el
        for (GraphLink link : toDel.getLinks()) {
            if (link.getTo() == toDel) {
                toDel.removeLink(link.getTo());
            }
        }
        values.remove(value);
        nodes.remove(toDel);

        return true;
    }

    public GraphNode get(String value) {
        return values.get(value);
    }

    public boolean addLink(String from, String to, int weight) {
        if (!values.containsKey(to) || !values.containsKey(from) || from.equals(to)) {
            return false;
        }

        GraphNode From = values.get(from);
        GraphNode To = values.get(to);
        From.addLink(To, weight);
        if (!isDirectionable) {
            To.addLink(From, weight);
        }
        return true;
    }

    public boolean removeLink(String from, String to) {
        if (!values.containsKey(to) || !values.containsKey(from)) {
            return false;
        }

        GraphNode From = values.get(from);
        GraphNode To = values.get(to);
        From.removeLink(To);
        if (!isDirectionable) {
            To.removeLink(From);
        }
        return true;
    }

    public List<GraphNode> getNodes() {
        return nodes;
    }

    public void addChangueListener(GraphChangueListener listener) {
        ChangueListeners.add(listener);
    }

    public void removeChangueListener(GraphChangueListener listener) {
        ChangueListeners.remove(listener);
    }

    public void fireNodeAddedEvent(GraphNode added) {
        for (GraphChangueListener listener : ChangueListeners) {
            listener.NodeAdded(added);
        }
    }

    public void fireNodeRemovedEvent(GraphNode removed) {
        for (GraphChangueListener listener : ChangueListeners) {
            listener.NodeDeleted(removed);
        }
    }

    public Graph createCopy() {
        Graph ret = new Graph();
        for (GraphNode node : nodes) {
            ret.add(node.getValue());
        }
        for (GraphNode node : nodes) {
            for (GraphLink link : node.getLinks()) {
                addLink(node.getValue(), link.getTo().getValue(), link.getWeight());
            }
        }
        return ret;
    }

    public TreePath getTreePath(String from) {
        int[] mins;
        int[] mark = new int[nodes.size()];
        Set<GraphNode> visits = new HashSet<>();
        Map<GraphNode, Integer> indexs = new HashMap<>();
        TreePath ret = new TreePath(this);
        int c = 0;
        for (GraphNode node : nodes) {
            indexs.put(node, c);
            c++;
        }
        mins = new int[nodes.size()];
        for (int i = 0; i < mins.length; i++) {
            mins[i] = Integer.MAX_VALUE;

        }

        mins[nodes.indexOf(get(from))] = 0;
        GraphNode current = get(from);
         mins[indexs.get(current)]=0;
         ret.setDistanceTo(current, 0);
        PriorityQueue<Path> links = new PriorityQueue<>();
        links.add(new Path(current, 0));
        Path curr;
        stop:
        for (GraphNode node : nodes) {
            do {
                if (links.isEmpty()) {
                    break stop;
                }
                curr = links.poll();
            } while (visits.contains(curr.getTarget()));
            current = curr.getTarget();
            visits.add(current);

            for (GraphLink link : current.getLinks()) {

                GraphNode dest = link.getTo();
                int coast = link.getWeight();

                if (mins[indexs.get(dest)] > mins[indexs.get(current)] + coast) {
                    mins[indexs.get(dest)] = mins[indexs.get(current)] + coast;
                    links.add(new Path(dest, mins[indexs.get(dest)]));
                    ret.addLink(dest, current);
                    ret.setDistanceTo(dest, mins[indexs.get(dest)]);
                }

            }
        }

        /* int i = 0;
        for (GraphNode node : nodes) {
        ret.setDistanceTo(node, mins[i]);
        i++;
        }*/
        return ret;
    }

}
