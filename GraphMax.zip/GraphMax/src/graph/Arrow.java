/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import graphics.point;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Polygon;

/**
 *
 * @author YULIER
 */
public class Arrow {

    point from, to;

    public Arrow(point from, point to) {
        this.from = from;
        this.to = to;
    }

    public void draw(Graphics gc) {

        point a = new point(to.getX(), to.getY());
        point b = new point(from.getX(), from.getY());
        double direc = a.getDirection(b);
        a.moveTo(a, direc, 15);
        b.moveTo(b,direc+Math.PI,15);
        double dir = a.getDirection(b);
        b.drawLine(gc, a);
        Polygon ang = new Polygon();
        ang.addPoint(a.getIntX(), a.getIntY());
        point c = new point(a, dir + Math.toRadians(20), 15);
        point d = new point(a, dir - Math.toRadians(20), 15);

        ang.addPoint(c.getIntX(), c.getIntY());
        ang.addPoint(d.getIntX(), d.getIntY());
        gc.fillPolygon(ang);
    }
}
