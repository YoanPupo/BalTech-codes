/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import graphics.DynamicList;
import graphics.point;
import java.awt.Color;
import java.awt.Graphics;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author YULIER
 */
public class TreePath {

    private List<PathNode> nodes;
    private Map<GraphNode, PathNode> map;

    public TreePath(Graph source) {
        nodes = new DynamicList<>();
        map = new HashMap<>();
        for (GraphNode node : source.getNodes()) {
            PathNode nod = new PathNode(node, null);
            map.put(node, nod);
            nodes.add(nod);
        }

    }

    public TreePath() {
        nodes = new DynamicList<>();
        map = new HashMap<>();
    }

    public void addLink(GraphNode start, GraphNode end) {
        PathNode st = map.get(start);
        PathNode pr = map.get(end);
        st.setParent(pr);
    }

    public void setDistanceTo(GraphNode node, int dist) {
        PathNode st = map.get(node);
        st.setDistance(dist);
    }

    public TreePath getPathTo(GraphNode dest) {

        TreePath ret = new TreePath();
        PathNode start = map.get(dest);
        ret.nodes.add(start);
        PathNode curr = start;
        while (curr != null) {
            PathNode nod=new PathNode(curr.getContent(), curr.getParent());
            nod.setDistance(curr.getDistance());
            ret.nodes.add(nod);
            curr = curr.getParent();
        }
        return ret;

    }

    public void draw(Graphics gc) {
        Set<PathNode> draws = new HashSet<>();
        for (PathNode node : nodes) {
            PathNode curr = node;
            while (curr.getParent() != null && !draws.contains(curr)) {
                point p1 = curr.getContent().getCenter();
                point p2 = curr.getParent().getContent().getCenter();
                gc.setColor(Color.YELLOW);
                new Arrow(p1, p2).draw(gc);
                new Arrow(p2, p1).draw(gc);
                gc.setColor(Color.WHITE);
                gc.drawString(curr.getDistance() + "", p1.getIntX() - 5, p1.getIntY() + 5);
                draws.add(curr);
                curr = curr.getParent();
            }
        }
    }

    public static class PathNode {

        private GraphNode content;
        private PathNode parent;
        int distance;

        public PathNode(GraphNode content, PathNode parent) {
            this.content = content;
            this.parent = parent;
        }

        public GraphNode getContent() {
            return content;
        }

        public void setContent(GraphNode content) {
            this.content = content;
        }

        public PathNode getParent() {
            return parent;
        }

        public void setParent(PathNode parent) {
            this.parent = parent;
        }

        public int getDistance() {
            return distance;
        }

        public void setDistance(int distance) {
            this.distance = distance;
        }

    }
}
