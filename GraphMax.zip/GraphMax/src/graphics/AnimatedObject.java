/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.awt.Graphics;
import java.awt.Image;

/**
 *
 * @author CARLOS
 */
public class AnimatedObject extends GraphicObject{
    protected AnimatedImage anima;
    
    public AnimatedObject(int id, AnimatedImage anim, double x, double y, double xSize, double ySize, int type) {
        super(id, null, x, y, xSize, ySize, type);
        anima=anim;
    }
     public AnimatedObject(int id, String path, double x, double y, double xSize, double ySize, int type) {
        super(id, null, x, y, xSize, ySize, type);
        anima=new AnimatedImage(path, AnimatedImage.MODE_LOOP);
    } public AnimatedObject(AnimatedObject other, int x, int y) {
        super(other.getId(), null, x, y, other.xSize, other.ySize, other.type);
        anima=other.getAnima();
    }public AnimatedObject( double x, double y, double xSize, double ySize){
        super(x, y, xSize, ySize);
        anima=new AnimatedImage();
    }

    public AnimatedImage getAnima() {
        return anima;
    }

    public void setAnima(AnimatedImage anima) {
        this.anima = anima;
    }
    public void print(Graphics gc){
        anima.draw(gc, x, y, xSize, ySize);
        
    }
    
}
