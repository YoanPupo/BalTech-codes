/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.io.*;

import javax.sound.sampled.*;

/**
 *
 * @author YULIER
 */
public class AudioPlayer {

    public static float mainLevel;
    Clip player;
    File source;
    Time time;
    FloatControl controls;
    int level;
    AudioManager manager = AudioManager.getDefaultAudioManager();

    public AudioPlayer() {

    }

    public AudioPlayer(String path) {
        this(new File(path));
    }

    public AudioPlayer(File source) {
        this.source = source;
        try {
            player = AudioSystem.getClip();
            player.open(AudioSystem.getAudioInputStream(source));
            player.addLineListener(new LineListener() {
                @Override
                public void update(LineEvent event) {
                    if (event.getType() == LineEvent.Type.STOP) {
                        player.setMicrosecondPosition(0);
                    }
                }
            });
            controls = (FloatControl) player.getControl(FloatControl.Type.MASTER_GAIN);
        } catch (Exception ex) {

        }
    }

    public void resetVolume() {
        setVolume(level);
    }

    public void play() {
        player.start();
    }

    public Time getTime() {
        return new Time(player.getMicrosecondPosition());
    }

    public long getPosition() {
        return player.getMicrosecondLength();
    }

    public void setVolume(double volume) {
        if (volume < 0) {
            volume = 0;
        }
        if (volume > 100) {
            volume = 100;
        }
        if (player.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
            FloatControl gainControl = controls;
            float range = gainControl.getMaximum() - gainControl.getMinimum();
            float gain = (float) ((range * (volume / 100.0 + manager.getBaseVolume() / 100.0)) + gainControl.getMinimum());
            if(gain>1)gain=1;
            gainControl.setValue(gain);
        } else {
            System.out.println("No Volume controls available");
        }

    }

    public long maxTime() {
        return player.getMicrosecondLength();
    }

    public void setPosition(long time) {
        player.setMicrosecondPosition(time);
    }

    public double getPercentTime() {
        return (double) getPosition() / maxTime() * 100;
    }

    public void setPercentTime(double percent) {
        setPosition((long) (percent / maxTime() * 100));
    }

    public boolean isPlaying() {
        return player.isRunning();
    }

    public void loop(int count) {
        player.loop(count);
    }

    public void loop() {
        player.loop(Clip.LOOP_CONTINUOUSLY);
    }

    public void stop() {
        player.stop();
        player.setMicrosecondPosition(0);
    }

    public void pause() {
        player.stop();
    }

}
