/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

/*
 * @author DOCENTE
 */
public class GraphicObject implements Comparable<GraphicObject> {

    protected transient Image image;
    public static JPanel pan = new JPanel();
    protected double x, y, xSize, ySize, xSpeed = 0, ySpeed = 0, prex, prey;
    protected int id, type, lastMov = 11;
    public static final int VERTICAL = 22, HORIZONTAL = 11;
    protected boolean visible=true;

    transient Universe rootUniverse;

    public GraphicObject(int id, Image image, double x, double y, double xSize, double ySize, int type) {
        this.image = image;
        this.x = x;
        this.y = y;
        this.xSize = xSize;
        this.ySize = ySize;
        this.id = id;
        this.type = type;
    }

    public GraphicObject(double x, double y, double xSize, double ySize) {
        this(0, null, x, y, xSize, ySize, 1);
    }

    public GraphicObject(GraphicObject base, double x, double y) {
        this.id = base.id;
        this.image = base.image;
        this.xSize = base.xSize;
        this.ySize = base.ySize;
        this.type = base.type;
        this.xSpeed = base.xSpeed;
        this.ySpeed = base.ySpeed;
        this.x = x;
        this.y = y;
    }

    public static BufferedImage loadImage(String path) {
        try {
            return ImageIO.read(new File(path));
        } catch (IOException ex) {
            System.err.println("error de lectura de imagen \n" + path + "\n" + ex.getLocalizedMessage());
            return null;
        }
    }

    public static BufferedImage[] loadImages(String cae, double rescalefactor) {
        File[] cont = new File(cae).listFiles();
        BufferedImage[] list = new BufferedImage[cont.length];
        Arrays.sort(cont);
        BufferedImage act;
        for (int i = 0; i < cont.length; i++) {
            try {
                act = ImageIO.read(cont[i]);
                BufferedImage ret = new BufferedImage((int) (act.getWidth() * rescalefactor), (int) (act.getHeight() * rescalefactor), BufferedImage.TYPE_INT_ARGB);
                ret.getGraphics().drawImage(act.getScaledInstance((int) (act.getWidth() * rescalefactor), (int) (act.getHeight() * rescalefactor), Image.SCALE_AREA_AVERAGING), 0, 0, pan);
                list[i] = ret;
            } catch (IOException ex) {
                System.err.println("error de lectura de imagen \n" + cae + "\n" + ex.getLocalizedMessage());

            }

        }
        return list;
    }

    public static void rescaleImages(Image[] list, int Whidt, int Height) {
        for (int i = 0; i < list.length; i++) {
            list[i] = list[i].getScaledInstance(Whidt, Height, Image.SCALE_AREA_AVERAGING);

        }
    }

    public static void rescaleImages(Image[] list, double rescalefactor) {
        for (int i = 0; i < list.length; i++) {
            Image act = list[i];
            list[i] = act.getScaledInstance((int) (act.getWidth(pan) * rescalefactor), (int) (act.getWidth(pan) * rescalefactor), Image.SCALE_AREA_AVERAGING);

        }
    }

    public static BufferedImage rescaleImage(Image act, double rescalefactor) {
        BufferedImage ret = new BufferedImage((int) (act.getWidth(pan) * rescalefactor), (int) (act.getHeight(pan) * rescalefactor), BufferedImage.TYPE_INT_ARGB);
        ret.getGraphics().drawImage(act.getScaledInstance((int) (act.getWidth(pan) * rescalefactor), (int) (act.getHeight(pan) * rescalefactor), Image.SCALE_AREA_AVERAGING), 0, 0, pan);

        return ret;

    }

    public void setDirection(double direction, double speed) {
        setxSpeed((speed * Math.cos(direction)));
        setySpeed((speed * Math.sin(direction)));
    }

    public point getSize() {
        return new point(getxSize(), getySize());
    }

    public static BufferedImage[] loadImages(String cae) {
        File[] cont = new File(cae).listFiles();
        BufferedImage[] list = new BufferedImage[cont.length];
        Arrays.sort(cont);
        BufferedImage act;
        for (int i = 0; i < cont.length; i++) {
            try {

                list[i] = ImageIO.read(cont[i]);
            } catch (IOException ex) {
            }

        }
        return list;
    }

    public synchronized Universe getRootUniverse() {
        return rootUniverse;
    }

    public synchronized void setRootUniverse(Universe rootUniverse) {
        this.rootUniverse = rootUniverse;
    }

    public void back() {
        setX(prex);
        setY(prey);
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
      //  prex=x;
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
      //  prey=y;
        this.y = y;
    }

    public point getPosition() {
        return new point(getX(), getY());
    }

    public void setPosition(point pos) {
        moveTo(pos.getX(), pos.getY());
    }

    public point getMaxPosition() {
        return new point(getX() + getxSize(), getY() + getySize());
    }

    public point getCenterPosition() {
        return new point(getX() + getxSize() / 2, getY() + getySize() / 2);
    }

    public double getxSize() {
        return xSize;
    }

    public GraphicObject setxSize(double xSize) {
        this.xSize = xSize;
        return this;
    }

    public double getySize() {
        return ySize;

    }

    public GraphicObject setySize(double ySize) {
        this.ySize = ySize;
        return this;
    }

    public double getxSpeed() {
        return xSpeed;
    }

    public GraphicObject setxSpeed(double xSpeed) {
        this.xSpeed = xSpeed;
        return this;
    }

    public double getySpeed() {
        return ySpeed;
    }
    public double getDirection(){
        return getPosition().getDirection(new point(getX()+getxSpeed(),getY()+getySpeed()));
    }
    public GraphicObject setySpeed(double ySpeed) {
        this.ySpeed = ySpeed;
        return this;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getLastMovement() {
        return lastMov;
    }

    public double XMax() {
        return getX() + getxSize();

    }

    public double YMax() {
        return getY() + getySize();

    }

    public point getCenter() {
        return getCenterPosition();
    }

    public void setCenter(point p) {
        setX(p.getX() - getxSize() / 2);
        setY(p.getY() - getySize() / 2);

    }

    public void up() {
        prey = this.getY();
        prex = this.getX();
        setY(getY() - getySpeed());
    }

    public void down() {
        prey = this.getY();
        prex = this.getX();
        setY(getY() + getySpeed());
    }

    public void right() {
        prey = this.getY();
        prex = this.getX();
        setX(getX() + getxSpeed());
    }

    public void left() {
        prey = this.getY();
        prex = this.getX();
        setX(getX() + getxSpeed());
    }

    public void move() {
        prey = this.getY();
        prex = this.getX();
        if (lastMov == VERTICAL) {
            setX(getX() + getxSpeed());
            lastMov = HORIZONTAL;
        } else {
            setY(getY() + getySpeed());
            lastMov = VERTICAL;
        }

    }
    public static void move(GraphicObject target) {
        target.prey = target.getY();
        target.prex = target.getX();
        if (target.lastMov == VERTICAL) {
            target.setX(target.getX() + target.getxSpeed());
            target.lastMov = HORIZONTAL;
        } else {
            target.setY(target.getY() + target.getySpeed());
            target.lastMov = VERTICAL;
        }

    }
    public void setSpeed(double speed) {
        xSpeed = ySpeed = speed;
    }

    public void setSize(double xSize, double ySize) {
        this.xSize = xSize;
        this.ySize = ySize;
    }

    public void moveTo(double x, double y) {
        prey = this.getY();
        prex = this.getX();
        setX(x);
        setY(y);
    }

    public GraphicObject translate(double x, double y) {
        setX(getX() + x);
        setY(getY() + y);
        return this;
    }

    public boolean collisionWith(GraphicObject other) {
        return (this.XMax() > other.getX() && this.getX() < other.XMax() && this.YMax() > other.getY() && this.getY() < other.YMax());
    } 
    public static boolean collisionWith(GraphicObject curr,GraphicObject other) {
        return (curr.XMax() > other.getX() && curr.getX() < other.XMax() && curr.YMax() > other.getY() && curr.getY() < other.YMax());
    }

    public void collisionBy(GraphicObject other) {

    }

    public double getPrex() {
        return prex;
    }

   

    public double getPrey() {
        return prey;
    }

  

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }
    
    public void print(Graphics gc) {

        drawImage(gc, image, getX(), getY(), getxSize(), getySize());
    }

    @Override
    public int compareTo(GraphicObject o) {
        return (id) - o.id;
    }

    public static void drawImage(Graphics gc, Image image, double x, double y, double xSize, double ySize) {
        gc.drawImage(image, (int) x, (int) y, (int) xSize, (int) ySize, pan);
    }

    public boolean acert(double x, double y) {
        return x > this.getX() && x < this.XMax() && y > this.getY() && y < this.YMax();
    }

    public boolean acert(point p) {
        return acert(p.getX(), p.getY());
    }

}
