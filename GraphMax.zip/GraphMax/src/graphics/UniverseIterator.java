/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;



/**
 *
 * @author CARLOS
 */
public class UniverseIterator {
    Universe univ;

    protected UniverseIterator(Universe univ) {
        this.univ = univ;
    }
    public void applyZoom(double percent){
        for (GraphicObject obj : univ) {
          obj.moveTo((obj.getX()*percent),(obj.getY()*percent));
          obj.setSize((obj.getxSize()*percent),(obj.getySize()*percent)); 
          obj.setxSpeed(obj.getxSpeed()*percent);
          obj.setySpeed(obj.getySpeed()*percent);
            
        }
        univ.setSize((int)(univ.getWidth()*percent), (int)(univ.getHeight()*percent));
         univ.setTraslate((int)(univ.getX()*percent),(int)(univ.getY()*percent));
    }
    public void applyTranslate(double trasx,double trasy){
        for (GraphicObject obj : univ) {
          obj.translate(trasx,trasy);
           
        }
        univ.setTraslate(univ.getX()+trasx,univ.getY()+ trasy);
    }
}
