/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferStrategy;
import javax.swing.*;

/**
 *
 * @author CARLOS
 */
public class FullScreenFrame {

    private static final DisplayMode[] MODES = new DisplayMode[]{new DisplayMode(1024, 600, 16, 0), new DisplayMode(640, 480, 32, 0), new DisplayMode(640, 480, 64, 0), new DisplayMode(640, 480, 16, 0), new DisplayMode(640, 480, 8, 0)};
    private final JFrame content;
    int width, height;
    DisplayMode original;
    Graphics gc;
    BufferStrategy strat;
    boolean active = false;
    GraphicsDevice gd;

    public FullScreenFrame(JFrame cont) {
        content = cont;
        content.setSize(GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().getSize());

        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        gd = ge.getDefaultScreenDevice();
        original = gd.getDisplayMode();
        on();
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }

    public void on() {

        if (!active) {

            content.setIgnoreRepaint(true);
            gd.setFullScreenWindow(content);
            if (gd.isDisplayChangeSupported()) {
                gd.setDisplayMode(getBestDisplayMode(gd));

            }
            width = content.getWidth();
            height = content.getHeight();
            content.createBufferStrategy(2);
            strat = content.getBufferStrategy();
            gc = strat.getDrawGraphics();

        }
        active = true;
    }

    public void repaint() {
        if (active) {
            gc = strat.getDrawGraphics();
            content.paint(gc);
            strat.show();
            gc.dispose();
        } else {

            content.paint(content.getGraphics());
        }
    }

    public void off() {
        if (active) {
            gd.setDisplayMode(original);
            gd.setFullScreenWindow(null);
        }
        active = false;
    }

    private static DisplayMode getBestDisplayMode(GraphicsDevice grde) {
        DisplayMode[] mod = grde.getDisplayModes();
        DisplayMode best = new DisplayMode(1024, 600, 4, 0);
        Dimension size = BufferedFrame.getMaxSize();
        System.out.println("max size : " + size);
        int w = size.width;
        int h = size.height;
        int disth = Integer.MAX_VALUE;
        int distv = Integer.MAX_VALUE;
        int dx, dy;
        for (DisplayMode mode : mod) {
          //  System.out.print("test >> " + DiMToString(mode));
            dx = distance(w, mode.getWidth());
            dy = distance(h, mode.getHeight());
            if (dx < disth && dy < distv) {
                disth = dx;
                distv = dy;
              //  System.out.println(" yes");
                best = mode;
            } else {
             //   System.out.println(" no");
            }
        }
      //  System.out.println(" end , best = " + DiMToString(best));
        return best;
    }

    private static int distance(int a, int b) {
        return Math.abs(Math.max(a, b) - Math.min(a, b));
    }

    private static String DiMToString(DisplayMode mode) {
        return "DisplayMode size = [ " + mode.getWidth() + " : " + mode.getHeight() + " ] BitDepth = " + mode.getBitDepth() + " refRate = " + mode.getRefreshRate();
    }

    public static void main(String[] args) {
        JFrame fr = new JFrame() {
            private boolean s = false;
            float col = 0;
            float in;

            @Override
            public void paint(Graphics gc) {
                gc.setColor(Color.PINK);
                in += 0.03;
                if (in >= 1) {
                    in = 0;
                }
                col = in;

                gc.fillRect(0, 0, getWidth(), getHeight());

                for (int i = 0; i < 260; i++) {
                    if (col < 1) {
                        col += 0.01;
                    } else {
                        col = 0;
                    }
                    gc.setColor(Color.getHSBColor(col, 1, 1));

                    gc.drawLine(i * 3, i * 3, getWidth(), getHeight());
                    // gc.drawLine(0, getHeight(), getWidth() - (i * 2), i * 5);

                }
                s = !s;
            }
        };
        fr.addKeyListener(new KeyAdapter() {

            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    System.exit(0);
                }
            }

        });
        fr.setUndecorated(true);
        final FullScreenFrame full = new FullScreenFrame(fr);
        full.on();
        
        TimerThread runner = new TimerThread(500,new Runnable() {

            @Override

            public void run() {
              
                    while (true) {
                        full.repaint();

                       
                    }
               
            }
        });
        runner.start();

    }

}
