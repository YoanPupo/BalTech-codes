/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author YULIER
 */
public class AudioManager {
    List<AudioPlayer>players=new ArrayList<>();
    int baseVolume=5;
    static AudioManager defaultAudioManager;
    public boolean add(AudioPlayer e) {
        return players.add(e);
    }

    public static AudioManager getDefaultAudioManager() {
        if(defaultAudioManager==null){
            defaultAudioManager=new AudioManager();
        }
        return defaultAudioManager;
    }
    
    public boolean remove(AudioPlayer o) {
        return players.remove(o);
    }

    public void clear() {
        players.clear();
    }

    public int getBaseVolume() {
        return baseVolume;
    }

    public void setBaseVolume(int baseVolume) {
        this.baseVolume = baseVolume;
        players.forEach((player) -> {
            player.resetVolume();
        });
    }
    
    
}
