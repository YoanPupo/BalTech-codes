/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

/**
 *
 * @author YULIER
 */
public class PrintThread extends Timer implements ActionListener{
    Component com;
    
    int x,y,width,height;
    public PrintThread(Component com,int delay) {
        super(delay,null);
        this.com = com;
        
        addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       com.repaint();
    }
}
