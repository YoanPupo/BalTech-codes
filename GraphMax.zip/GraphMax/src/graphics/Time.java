/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author CARLOS
 */
public class Time {
    private int hour ,min ,sec,dec;

    public Time(int hour, int min, int sec, int dec) {
        this.hour = hour;
        this.min = min;
        this.sec = sec;
        this.dec = dec;
    }

    public Time() {
        this(0,0,0,0);
    }
    public Time(long time){
         long res=time/1000000;
        
        sec = (int) (res%60);
        res=res/60;
        min = (int) (res%60);
        res=res/60;
        hour = (int) (res%60);
    }
     public Time(Time other) {
        this(other.hour,other.min,other.sec,other.dec);
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getSec() {
        return sec;
    }

    public void setSec(int sec) {
        this.sec = sec;
    }

    public int getDec() {
        return dec;
    }

    public void setDec(int dec) {
        this.dec = dec;
    }
    public Time getNext(){
       dec++;
                if (dec == 10) {
                    sec++;

                    dec = 0;
                }
                if (sec == 60) {
                    min++;
                    sec = 0;
                }
                if (min == 60) {
                    hour++;
                    min = 0;
                }
                Time ret=new Time(this);
                this.prev();
                return ret;
    }
    public Time next(){
       dec++;
                if (dec == 10) {
                    sec++;

                    dec = 0;
                }
                if (sec == 60) {
                    min++;
                    sec = 0;
                }
                if (min == 60) {
                    hour++;
                    min = 0;
                }
                return this;
    }
    public Time prev(){
          dec--;
                if (dec == 0) {
                    sec--;

                    dec =100;
                }
                if (sec == 0) {
                    min--;
                    sec = 60;
                }
                if (min == 0) {
                    hour--;
                    min = 60;
                }
                return this;
    }
    public String toString(){
             return (hour < 10 ? "0" + hour : hour) + " : " + (min < 10 ? "0" + min : min) + " : " + (sec < 10 ? "0" + sec : sec);
   
    }
}
