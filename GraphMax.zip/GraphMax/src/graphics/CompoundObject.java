/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.awt.Graphics;

/**
 *
 * @author YULIER
 */
public class CompoundObject extends GraphicObject{
    Universe container;
    public CompoundObject(double x, double y, double xSize, double ySize) {
        super(x, y, xSize, ySize);
        container=new Universe();
    }

    public Universe getContainer() {
        return container;
    }
    
    public boolean add(GraphicObject gr) {
        return container.add(gr);
    }

    public void addLast(GraphicObject value) {
        container.addLast(value);
    }

    public void addFirst(GraphicObject value) {
        container.addFirst(value);
    }

    public synchronized void move() {
        container.move();
    }

    public GraphicObject getIn(point position) {
        return container.getIn(position);
    }

    public GraphicObject getIn(double x, double y) {
        return container.getIn(x, y);
    }

    public GraphicObject[] getAllIn(double x, double y) {
        return container.getAllIn(x, y);
    }

    public GraphicObject[] getAllIn(point position) {
        return container.getAllIn(position);
    }

  
   

    public void print(Graphics gr) {
        container.print(gr,false);
    }
    
}
