package graphics;


import ObjectSerializator.DataReader;
import ObjectSerializator.DataWriter;
import ObjectSerializator.ReadException;
import ObjectSerializator.Saveable;
import ObjectSerializator.WriteException;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import javax.swing.JPanel;

public class point extends Point2D implements Saveable{
    public static final point ORIGIN_POINT=new point(0,0);
    double x, y;

    public point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public point(point other) {
        this.x = other.x;
        this.y = other.y;
    }

    public point(point other, double direction, double dist) {
        x =  (other.x + dist * Math.cos(direction));
        y =  (other.y + dist * Math.sin(direction));
    }
     public point(String code){
        int index=code.indexOf(",");
        setX(java.lang.Double.parseDouble(code.substring(0, index)));
        setY(java.lang.Double.parseDouble(code.substring( index+1)));
    }
    public point() {
        this(0, 0);
    }
   static JPanel pan=new JPanel();
    public static void drawImage(Graphics gc,Image img,point position,double width,double height){
        gc.drawImage(img, (int)position.x, (int)position.y,(int)width, (int)height,pan);
        
    }

    public point(MouseEvent e) {
       this(e.getX(),e.getY());
    }

    public point moveTo(point other, double direction, double dist) {
        setX(other.getX() + dist * Math.cos(direction));
        setY(other.getY() + dist * Math.sin(direction));
        return this;
    }
     public static point moveTo(point target,point other, double direction, double dist) {
        target.setX(other.getX() + dist * Math.cos(direction));
        target.setY(other.getY() + dist * Math.sin(direction));
        return target;
    }
     public double getDirection(){
       
        return getDirection(ORIGIN_POINT);
    
    }
    public double getDirection(point dest){
        
       return getDirection(getX(), getY(), dest.getX(), dest.getY());
    }
    public void setPoint(point other){
        setX(other.getX());
        setY(other.getY());
    }
    public double distanceTo(point p2) {
        if(equals(p2))return 0;
        return  distance(p2);
    }public static double getDirection(double x,double y ,double x2,double y2){
        double dx=x2-x;
        double dy=y2-y;
        double ret;
       
            ret=Math.atan2(dy, dx);
      
        
        return ret;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }
    public void translate(double x,double y){
        setX(getX()+x);
        setY(getY()+y);
        
    }
    public void rotate(point center,double direction){
        double dir=getDirection(getX(), getY(), center.getX(), center.getY());
        moveTo(center,dir+direction,distanceTo(center));
        
    }
    public static void rotate(point target,point center,double direction){
          double dir=getDirection(target.getX(), target.getY(), center.getX(), center.getY());
       
        point.moveTo(target,center,dir+direction,target.distanceTo(center));
        
    }

    public double getY() {
        return y;
    }
    public int getIntX(){
        return (int)getX();
    }
    public int getIntY(){
        return (int)getY();
    }
    public void setY(double y) {
        this.y = y;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + (int) ((int)(this.x*100) ^ ((int)(this.x*100) >>> 32));
        hash = 97 * hash + (int) ((int)(this.y*100) ^ ((int)(this.y*100) >>> 32));
        return hash;
    }

  

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final point other = (point) obj;
        if (this.getX() != other.getX()) {
            return false;
        }
        return this.getY() == other.getY();
    }
    
    public String toString(){
        return "[ "+getX()+" , "+getY()+" ]";
    }

    public void draw(Graphics gc) {
        gc.drawRect((int)getX()-1, (int)getY()-1, 2, 2);
   }
    public void drawLine(Graphics gc,point other){
        gc.drawLine(getIntX(), getIntY(), other.getIntX(),other. getIntY());
    }

    @Override
    public void setLocation(double x, double y) {
       setX(x);
       setY(y);
    }

    public void moveTo(MouseEvent e) {
       setLocation(e.getX(),e.getY());
    }

    @Override
    public void load(DataReader reader) throws ReadException {
       setX(reader.readDouble());
       setY(reader.readDouble());
    }

    @Override
    public void print(DataWriter writer) throws WriteException {
       writer.writeDouble(getX());
       writer.writeDouble(getY());
    }

        
        
    
}
