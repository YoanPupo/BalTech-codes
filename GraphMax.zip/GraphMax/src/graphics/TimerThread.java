/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author CARLOS
 */
public class TimerThread {

    private Thread thread;
    private Runnable Runner;
    int Delay;
    long prev;
    long cont;
    boolean running = false;
    ExecutorService serv=Executors.newCachedThreadPool();
    public TimerThread(int delay, Runnable runner) {
        this.Runner = runner;
        Object syn = new Object();
        this.Delay = delay;
        this.cont = prev = 0;
        synchronized (syn) {
            thread = new Thread() {

                public void run() {
                    while (true) {
                        while (running) {
                            try {

                                if (cont - prev >= Delay) {
                                    serv.execute(Runner);
                                    prev = System.currentTimeMillis();
                                }
                                sleep(0, 100);
                                cont = System.currentTimeMillis();

                            } catch (Exception e) {
                                System.err.println("thread error "+e.getLocalizedMessage());
                            }
                        }
                        try {
                           thread.sleep(100);
                        } catch (Exception e) {
                            System.err.println("wait error "+e.getLocalizedMessage());
                        }

                    }
                }
            };
            
        }
        thread.start();
    }

    public synchronized boolean isRunning() {
        return running;
    }

    public synchronized void start() {
        if (!running) {
            running = true;

            synchronized (thread) {
                thread.notifyAll();
            }
        }

    }

    public synchronized void stop() {
        running = false;
    }
}
