/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.HeadlessException;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.*;
import javax.swing.JFrame;

/**
 *
 * @author CARLOS
 */
public class BufferedFrame extends JFrame {

    Dimension dim;
    double transInX, transInY;
    boolean translateEnable = true;
     BufferStrategy strat;

    public BufferedFrame() throws HeadlessException {
        this(false);
    }

    public BufferedFrame(String title) throws HeadlessException {
        super(title);

    }

    public BufferedFrame(boolean full) throws HeadlessException {
        this("frame");
        if (full) {
            setSize(GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().getSize());

        }
    }

    public static Dimension getMaxSize() {
        return GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().getSize();
    }

 

    public void fullSize() {
        setSize(GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().getSize());
    }

    public void toFullScreen() {
        fullSize();
        setUndecorated(true);
        
    }

    @Override
    public void repaint() {
      
        if (strat == null) {
            createBufferStrategy(2);
            strat = getBufferStrategy();
        }

       
      
        Graphics gd = strat.getDrawGraphics();
        paint(gd);

        strat.show();
        gd.dispose();
      
    }
}
