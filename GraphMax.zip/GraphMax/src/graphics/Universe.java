/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import ObjectSerializator.DataReader;
import ObjectSerializator.DataWriter;
import ObjectSerializator.ReadException;
import ObjectSerializator.Saveable;
import ObjectSerializator.TextDataWriter;
import ObjectSerializator.WriteException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.swing.JPanel;

/**
 *
 * @author DOCENTE
 */
public class Universe extends DynamicList<GraphicObject> implements Externalizable {

    JPanel obs = new JPanel();

    Graphics grs;
    private int width = 6000, height = 6000;

    List<CollisionListener> action;
    double x, y;
    AbstractCollection<Object> col;

    public Universe() {
        super();
        action = new ArrayList<>();

    }

    public void setWidth(int whidt) {
        this.width = whidt;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    @Override
    public boolean remove(Object o) {

        return super.remove(o);
    }

    @Override
    public void add(int index, GraphicObject gr) {
        if (gr == null) {
            throw new NullPointerException();
        }
        gr.setRootUniverse(this);
        super.add(index, gr);
    }

    @Override
    public boolean add(GraphicObject gr) {
        if (gr == null) {
            throw new NullPointerException();
        }

        boolean ret = super.add(gr);
        gr.setRootUniverse(this);
        return ret;
    }

    @Override
    public GraphicObject deleteFirst() {
        GraphicObject ret = super.deleteFirst();
        ret.setRootUniverse(null);
        return ret;
    }

    @Override
    public GraphicObject deleteLast() {
        GraphicObject ret = super.deleteLast();
        ret.setRootUniverse(null);
        return ret;
    }

    @Override
    public void addLast(GraphicObject value) {
        super.addLast(value);
        value.setRootUniverse(this);
    }

    @Override
    public void addFirst(GraphicObject value) {
        super.addFirst(value);
        value.setRootUniverse(this);
    }

    public void setSize(int x, int y) {
        width = x;
        height = y;
    }

    public void setSize(Dimension size) {
        this.setSize(size.width, size.height);
    }

    public UniverseIterator getUniverseIterator() {
        return new UniverseIterator(this);
    }

    public synchronized void move() {
        for (GraphicObject get : this) {
            get.move();

        }

    }

    public synchronized void step() {
        for (GraphicObject x : this) {
            x.move();
            for (GraphicObject y : this) {
                if (y.getType() == 0 || x.getType() == 0) {
                    continue;
                }
                if (y == x) {
                    continue;
                }
                if (x.collisionWith(y)) {
                    x.collisionBy(y);
                    for (CollisionListener listener : action) {
                        listener.collision(x, y);
                    }

                }

            }
            x.move();
            for (GraphicObject y : this) {
                if (y.getType() == 0 || x.getType() == 0) {
                    continue;
                }
                if (y == x) {
                    continue;
                }
                if (x.collisionWith(y)) {
                    x.collisionBy(y);
                    for (CollisionListener listener : action) {
                        listener.collision(x, y);
                    }

                }

            }

        }
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public GraphicObject getIn(point position) {
        return getIn(position.getX(), position.getY());
    }

    public GraphicObject getIn(double x, double y) {
        for (GraphicObject thi : this) {
            if (thi.acert(x, y)) {
                return thi;
            }
        }
        return null;
    }

    public GraphicObject[] getAllIn(double x, double y) {
        ArrayList<GraphicObject> list = new ArrayList<>();
        int cont = 0;
        for (GraphicObject thi : this) {
            if (thi.acert(x, y)) {
                list.add(thi);
                cont++;
            }
        }
        return list.toArray(new GraphicObject[cont]);
    }

    public GraphicObject[] getAllIn(point position) {
        return Universe.this.getAllIn(position.getX(), position.getY());
    }

    public boolean include(double x, double y) {
        return x > getX() && x < getX() + getWidth() && y > getY() && y < getY() + getHeight();
    }

    public boolean include(point position) {
        return include(position.getX(), position.getY());
    }

    public synchronized void addCollisionListener(CollisionListener act) {
        if (!action.contains(act)) {
            this.action.add(act);
        }
    }

    public synchronized void removeCollisionListener(CollisionListener act) {
        action.remove(act);
    }

    public synchronized boolean collisionProbe() throws RuntimeException {
        boolean is = false;

        for (GraphicObject x : this) {

            if (x.getType() == 0) {
                continue;
            }

            for (GraphicObject y : this) {

                if (y.getType() == 0 || x.getType() == 0) {
                    continue;
                }
                if (y == x) {
                    continue;
                }
                if (x.collisionWith(y)) {
                    x.collisionBy(y);
                    for (CollisionListener listener : action) {
                        listener.collision(x, y);
                    }
                    is = true;
                }

            }

        }

        return is;
    }

    public void sort() {
        DynamicList.sort(this);

    }

    public CollisionListener[] getActions() {
        return (CollisionListener[]) action.toArray();
    }

    public double getXMax() {
        return x + width;
    }

    public double getYMax() {
        return y + height;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setTraslate(double x, double y) {
        this.x = x;
        this.y = y;

    }

    public void print(Graphics gr, boolean clear) {
        grs = gr;
        Color col = grs.getColor();
        grs.setColor(Color.CYAN);
        if (clear) {
            grs.fillRect(0, 0, width, height);
        }

        for (GraphicObject thi : this) {
            if (thi.isVisible()) {
                thi.print(grs.create());
            }

        }
        grs.setColor(col);

    }

    public void print(Graphics gr) {
        print(gr, true);
    }

    public void print(Graphics gr, int x, int y, int widht, int height) {
        this.print(gr, x, y, widht, height, true);
    }

    GraphicObject mon = new GraphicObject(0, 0, 1, 1);

    public void print(Graphics grs, double x, double y, double width, double height, boolean clear) {
        Graphics2D gc = (Graphics2D) grs;
        Color col = grs.getColor();
        mon.moveTo(x, y);
        mon.setSize(width, height);
        grs.setColor(Color.CYAN);
        if (clear) {
            grs.fillRect((int) x, (int) y, (int) width, (int) height);
        }

        for (GraphicObject thi : this) {
            if (mon.collisionWith(thi) && thi.isVisible()) {
                thi.print(gc.create());
            }
        }
        grs.setColor(col);

    }

    public void moveTo(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void print(DataWriter writer) throws WriteException {

        for (Object sav : this) {
            if (sav instanceof Saveable) {
                writer.writeObject((Saveable) sav);
            }
        }
        writer.writeObject(new endMark());

    }

    @Override
    public void load(DataReader reader) throws ReadException {
        while (true) {
            Object read = reader.readObject();
            if (read instanceof endMark) {
                break;
            }
            add((GraphicObject) read);
        }
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        for (Object sav : this) {
            if (sav instanceof Externalizable) {
                out.writeObject((Externalizable) sav);
            }
        }
        out.writeObject(new endMark());
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        while (true) {
            Object read = in.readObject();
            if (read instanceof endMark) {
                break;
            }
            add((GraphicObject) read);
        }
    }

    public static class endMark implements Saveable, Externalizable {

        public endMark() {

        }

        @Override
        public void load(DataReader reader) throws ReadException {
        }

        @Override
        public void print(DataWriter writer) throws WriteException {
        }

        @Override
        public void writeExternal(ObjectOutput out) throws IOException {
        }

        @Override
        public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        }

    }
}
