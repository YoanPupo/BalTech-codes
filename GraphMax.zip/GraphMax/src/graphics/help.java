/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.applet.Applet;
import java.applet.AudioClip;
import java.io.File;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JOptionPane;

/**
 *
 * @author CARLOS
 */
public class help {

    public static AudioClip loadAudioClip(String path) {
        try {
            return Applet.newAudioClip(new File(path).toURI().toURL());
        } catch (Exception e) {
            return null;
        }
    }

    public static Clip loadFileClip(String path) {
        File file = new File(path);
        try {
            Clip player = AudioSystem.getClip();
            player.open(AudioSystem.getAudioInputStream(file));
            
            return player;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR\nloadFileClip\n" + e);
        }
        return null;

    }
}
