/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.awt.*;
import javax.swing.JLabel;

/**
 *
 * @author CARLOS
 */
public class AnimatedImage {

    private Image[] images;
    private Image current;
    private int index;
    private int mode;
    boolean dir;
    private int retard = 0, retcon = 0;
    public static final int MODE_STOP = 1;

    public static final boolean FRONT = true;
    public static final boolean BACK = false;

    public static final int MODE_LOOP = 2;
    public static final int MODE_ZIGZAG = 3;

    public AnimatedImage(Image[] list, int mode) {
        this.dir = FRONT;
        this.images = list;
        this.mode = mode;
        this.index = 0;
        this.current = images[index];
    }

    public AnimatedImage(String path, int mode) {
        this.dir = FRONT;
        this.images = GraphicObject.loadImages(path);
        this.mode = mode;
        this.index = 0;
        this.current = images[index];
    }

    public AnimatedImage(AnimatedImage other) {
        this.dir = FRONT;
        this.images = other.images;
        this.index = other.index;
        this.mode = other.mode;
        this.current = other.current;
    }

    AnimatedImage() {
        //this(null,MODE_STOP);
    }

    public void restart() {
        index = dir == FRONT ? 0 : images.length - 1;
        current=images[index];
        retcon=0;
    }

    public boolean isAllImages() {
        return index == (dir == FRONT ? images.length - 1 : 0);
    }

    public Image next() {
        if (++retcon < retard) {
            return current;
        }
        retcon = 0;
        switch (mode) {
            case MODE_STOP:
                index = isAllImages() ? index : dir ? index + 1 : index - 1;
                break;
            case MODE_LOOP:
                index = isAllImages() ? dir ? 0 : images.length - 1 : dir ? index + 1 : index - 1;
                break;
            case MODE_ZIGZAG:
                index += dir ? index + 1 : index - 1;
                if (isAllImages()) {
                    dir = !dir;
                }
                break;
            default:
                break;
        }
        return current = images[index];
    }

    public void setDirection(boolean direction) {
        dir = direction;
    }

    public int getRetard() {
        return retard;
    }

    public Image getCurrent() {
        return current;
    }

    public void setCurrent(Image current) {
        this.current = current;
    }

    public void setRetard(int retard) {
        this.retard = Math.abs(retard);
    }

    public int getIndex() {
        return index;
    }

    public Image[] getImages() {
        return images;
    }

    public void setImages(Image[] images) {
        if (images == this.images) {
            return;
        }
        this.images = images;
        this.index = 0;
    }

    public void setImages(String path) {
        this.images = GraphicObject.loadImages(path);
        this.index = 0;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        if (mode == this.mode) {
            return;
        }
        this.mode = mode;
        this.index = 0;
    }

    private static JLabel lab = new JLabel();

    public void draw(Graphics gc, int index, double x, double y, double widht, double height) {

        gc.drawImage(current, (int) x, (int) y, (int) widht, (int) height, lab);

    }

    public void draw(Graphics gc, double x, double y, double widht, double height) {

        gc.drawImage(current, (int) x, (int) y, (int) widht, (int) height, lab);

    }

}
