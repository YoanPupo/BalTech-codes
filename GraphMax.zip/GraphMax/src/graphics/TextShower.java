/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

/**
 *
 * @author YULIER
 */
public class TextShower extends GraphicObject{
    String text;
    Font font;
    Color color;
    public static final String EMPTY_TEXT="";
    public TextShower(double x, double y) {
        super(x, y, 1, 1);
        this.text=EMPTY_TEXT;
        this.font=new Font(Font.SANS_SERIF,Font.ITALIC,40);
        this.color=Color.RED;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Font getFont() {
        return font;
    }

    public void setFont(Font font) {
        this.font = font;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }
    public void ShowMessage(String text,final int delay){
        setText(text);
        new Thread(){
            public void run(){
                try {
                    Thread.sleep(delay);
                    setText(EMPTY_TEXT);
                } catch (Exception e) {
                }
            }
        }.start();
    }
    @Override
    public void print(Graphics gc) {
        gc.setFont(font);
        gc.setColor(color);
        FontMetrics fm=gc.getFontMetrics();
        int length=fm.stringWidth(text);
        gc.drawString(text, (int) (x-length/2), (int) y);
    }
    
    
}
