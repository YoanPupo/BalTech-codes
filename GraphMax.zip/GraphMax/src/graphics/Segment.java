/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

/**
 *
 * @author YULIER
 */
public class Segment {
    public static point getIntersectionPoint(double x1,double y1,double x2,double y2){
        point ret=new point();
        
       
        try {
            ret.setX((y2-y1)/(x1-x2));
            ret.setY(x1*(y2-y1)/(x1-x2)+y1);
        } catch (Exception e) {
            return null;
        }
         return ret;
    }
}
