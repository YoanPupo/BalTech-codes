/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import static graphics.GraphicObject.pan;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;

/**
 *
 * @author CARLOS
 */
public class ColorDecoder {
    public static Color createAlphaColor(Color col,int alpha){
        return new Color(col.getRed(),col.getGreen(),col.getBlue(),alpha);
    }
    public static float getHue(Color col){
        float[]cat=new float[3];
        Color.RGBtoHSB(col.getRed(),col.getGreen(),col.getBlue(),cat);
        return cat[0];
    }
    
      static AlphaComposite com = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.8f);
      public static BufferedImage filterImage(BufferedImage cab, Color changue) {
        BufferedImage ret = new BufferedImage(cab.getWidth(pan), cab.getHeight(pan), BufferedImage.TYPE_INT_ARGB);
        Graphics2D gc = ret.createGraphics();
        gc.drawImage(cab, 0, 0, pan);
        gc.setXORMode(changue);

        gc.drawImage(cab, 0, 0, pan);
        gc.setPaintMode();
        gc.setComposite(com);
        gc.drawImage(cab, 0, 0, pan);
      
        return ret;
    }

    public static void filterImages(BufferedImage[] cab, Color changue) {
        for (int i = 0; i < cab.length; i++) {
            BufferedImage source = (BufferedImage) cab[i];
            cab[i] = filterImage(source, changue);

        }
       
    }

    public static void applyChangueColor(BufferedImage im, Color source, Color target, int margin) {
        BufferedImage img = (BufferedImage) im;
        for (int i = 0; i < img.getWidth(); i++) {
            for (int j = 0; j < img.getHeight(); j++) {
                int color = img.getRGB(i, j);
                if (compareColor(source, new Color(color), margin)) {
                    img.setRGB(i, j, target.getRGB());
                }
            }
        }
    }

    public static boolean compareColor(Color testa, Color testb, int margin) {
        if (Math.abs(testa.getRed() - testb.getRed()) < margin && Math.abs(testa.getGreen() - testb.getGreen()) < margin && Math.abs(testa.getBlue() - testb.getBlue()) < margin && Math.abs(testa.getAlpha() - testb.getAlpha()) < margin) {
            return true;
        }
        return false;
    }

    public static void applyChangueColor(BufferedImage[] cab, Color source, Color target, int margin) {
        for (int i = 0; i < cab.length; i++) {

            applyChangueColor((BufferedImage) cab[i], source, target, margin);

        }

    } 
    public static point indexColor(BufferedImage source,Color target,int margin){
     
       
        for (int x = 0; x < source.getWidth(); x++) {
            for (int y = 0; y < source.getHeight(); y++) {
                if(compareColor(target, new Color(source.getRGB(x, y)), margin)){
                    return new point(x,y);
                }
            }
        }
        return new point(-1,-1);
    }
}
