/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import ObjectSerializator.DataReader;
import ObjectSerializator.DataWriter;
import ObjectSerializator.ReadException;
import ObjectSerializator.Saveable;
import ObjectSerializator.TextDataReader;
import ObjectSerializator.TextDataWriter;
import ObjectSerializator.WriteException;
import graphics.*;
import graphics.GraphicObject;
import graphics.Universe;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author CARLOS
 */
public class serialMap {

    Universe univ;
    TextDataReader reader;
    TextDataWriter writer;
    //ObjectInputStream reader;
    //  ObjectOutputStream writer;
    File def;

    public serialMap(Universe univ) {
        this.univ = univ;
    }

    public serialMap(Universe univ, File path) {
        this(univ);
        def = path;

    }

    public void setFile(File f) {
        def = f;

    }

    public boolean save() throws Exception {
        try {
            writer = new TextDataWriter(def);

            for (Object sav : univ) {
                if (sav instanceof Saveable) {
                    writer.writeObject((Saveable) sav);
                }
            }
            writer.writeObject(new endMark());

        } catch (Exception ex) {
            System.err.println("save game error " + ex.getLocalizedMessage());
            throw ex;

        }
        return true;
    }

    public boolean load() throws Exception {
        reader = new TextDataReader(def);
        while (true) {
            Object read = reader.readObject();
            if (read instanceof endMark) {
                break;
            }
            univ.add((GraphicObject) read);
        }

        System.out.println("graphics.serialMap.load()" + univ.size());

        return true;

    }

    public DataReader getReader() {
        if (reader == null) {
            reader = new TextDataReader(def);
        }
        return reader;
    }

    public DataWriter getWriter() {
        if (writer == null) {
            writer = new TextDataWriter(def);
        }
        return writer;
    }

    public void close() {
        try {
            if (reader != null) {
                
            }
            if (writer != null) {
                writer.close();
            }
        } catch (Exception ex) {

        }
    }

    public static class endMark implements Saveable {

        public endMark() {

        }

        @Override
        public void load(DataReader reader) throws ReadException {
        }

        @Override
        public void print(DataWriter writer) throws WriteException {
        }

    }

}
