/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import java.io.File;
import java.util.List;

/**
 *
 * @author YULIER
 */
public class AudioMultiPlayer extends AudioPlayer {

    DynamicList<AudioPlayer> players = new DynamicList<>();

    public AudioMultiPlayer(String path, int count) {
        this(new File(path), count);
    }

    public AudioMultiPlayer(File source, int count) {
        for (int i = 0; i < count; i++) {
            players.add(new AudioPlayer(source));
        }
    }

    public List<AudioPlayer> getPlayList() {
        return players;
    }

    @Override
    public void pause() {
        for (AudioPlayer player : players) {
            player.pause();
        }
        
    }
     @Override
    public void stop() {
        for (AudioPlayer player : players) {
            player.stop();
        }
        
    }
    @Override
    public void setVolume(double level) {
        for (AudioPlayer player : players) {
            player.setVolume(level);
        } 
    }

    @Override
    public void resetVolume() {
        for (AudioPlayer player : players) {
            player.resetVolume();
        }
    }

    public void play() {
        for (AudioPlayer player : players) {
            if (!player.isPlaying()) {
                player.play();
                break;
            }
        }
    }
    public AudioPlayer getPlayer(){
        for (AudioPlayer player : players) {
            if (!player.isPlaying()) {
                players.remove(player);
                return player;
            }
        }
        return null;
    }
    public void freePlayer(AudioPlayer player){
        if(!players.contains(player))
        players.addLast(player);
    }
}
